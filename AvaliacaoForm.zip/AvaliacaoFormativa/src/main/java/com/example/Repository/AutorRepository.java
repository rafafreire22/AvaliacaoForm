package com.example.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AutorRepository<Autor> extends JpaRepository<Autor, Long> { 

}


