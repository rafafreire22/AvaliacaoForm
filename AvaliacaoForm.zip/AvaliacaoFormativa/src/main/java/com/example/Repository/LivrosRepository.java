package com.example.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LivrosRepository<Livros> extends JpaRepository<Livros, Long> {
 
}
