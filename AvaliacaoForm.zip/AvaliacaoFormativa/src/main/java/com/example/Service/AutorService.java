package com.example.Service;

import java.util.List;

import org.apache.tomcat.util.net.Acceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Repository.AutorRepository;

@Service
public class AutorService<Autor> {
	private final AutorRepository autorRepository;

	@Autowired
	public AutorService(AutorRepository autorRepository) {
		this.autorRepository = autorRepository;
	}

	public List<Autor> getAllAutor() {
		return autorRepository.findAll();
	}

	public void deleteAutor(Long id) {
		autorRepository.deleteById(id);
	}
}

