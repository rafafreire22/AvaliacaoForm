package com.example.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entities.CategoriaEntities;
import com.example.Repository.CategoriaRepository;

@Service
public class CategoriaService {
	private final CategoriaRepository categoriaRepository;
	

	@Autowired
	public CategoriaService(CategoriaRepository categoriaRepository) {
		this.categoriaRepository = categoriaRepository;
	}

	public CategoriaEntities saveCategoria(CategoriaEntities categoria) {
		return categoriaRepository.save(categoria);
	}

	public CategoriaEntities getCategoriaById(Long id) {
		return categoriaRepository.findById(id).orElse(null);
	}

	public List<CategoriaEntities> getAllCategoria() {
		return categoriaRepository.findAll();
	}

	public void deleteCategoria(Long id) {
		categoriaRepository.deleteById(id);
	}
}


