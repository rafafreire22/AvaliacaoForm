package com.example.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Repository.LivrosRepository;

@Service
public class LivrosService<Livros> {
	private final LivrosRepository LivrosRepository = null;
	
	@Autowired
	private LivrosRepository livrosRepository;

	public List<Livros> getAllLivros() {
		return livrosRepository.findAll();
	}
	public Livros saveLivros(Livros livros) {
		return (Livros) livrosRepository.save(livros);
	}

}
