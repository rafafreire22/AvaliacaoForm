package com.example.Controller;

import java.util.List;

import org.apache.tomcat.util.net.Acceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.Autor;
import com.example.Service.AutorService;
import com.example.Service.LivrosService;

@RestController
@RequestMapping("/autor")

public class AutorController<Autor> {
	private static final String Autor = null;
	@Autowired
    private final AutorService autorService;
	
	@Autowired
    public AutorController(AutorService autorSAutorService) {
        this.AutorService = AutorService;
    }

    @PostMapping
    public Autor createAutor(@RequestBody Autor autor) {
        return AutorService.saveLivros(Autor);
    }

    public AutorService getAutorService() {
		return autorService;
	}

	@GetMapping("/{id}")
    public Autor getAutor(@PathVariable Long id) {
        return AutorService.getAutorById(id);
    }

	public Autor getAutorById(Long id) {
		return autorService.getAutorById(id);
	}

	public List<Autor> getAllAutor() {
		return autorService.getAllAutor();
	}

	public void deleteAutor(Long id) {
		autorService.deleteAutor(id);
	}
}
