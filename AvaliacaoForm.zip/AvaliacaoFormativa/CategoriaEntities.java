package com.example.Entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Categoria")
public class CategoriaEntities {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idCat;

	private String nome;

	private String descricao;
	
	public CategoriaEntities() {
		
		public void Livros(Integer idCat, String nome, String descricao) {
			this.idCat = idCat;
			this.nome = nome;
			this.descricao = descricao;
		}

		public Integer getId() {
			return idCat;
		}

		public void setIdCat(Integer idCat) {
			this.idCat = idCat;
		}


		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public String getDescricao() {
			return descricao;
		}

		public void setDescricao(String descricao) {
			this.descricao = descricao;

		
	}
}
